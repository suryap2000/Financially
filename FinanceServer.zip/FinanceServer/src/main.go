package main

import (
	"context"
	"fmt"
	"log"

	"cloud.google.com/go/firestore"
	"github.com/gin-gonic/gin"
	"google.golang.org/api/iterator"
)

type Word struct {
	Term       string `json:term`
	Definition string `json:definition`
}

func QueryStrings(c *gin.Context) {
	//word := c.Query("word")
	var words []Word
	projectID := "rising-theater-267614"
	ctx := context.Background()
	client, err := firestore.NewClient(ctx, projectID)
	if err != nil {
		log.Fatalf("Failed to create client: %v", err)
	}
	iter := client.Collection("FinLit").Documents(ctx)
	for {
		doc, err := iter.Next()
		if err == iterator.Done {
			break
		}
		if err != nil {
			log.Fatalf("Failed to iterate: %v", err)
		}
		term := Word{
			Term:       doc.Data()["Term"].(string),
			Definition: doc.Data()["Definition"].(string),
		}
		words = append(words, term)
		fmt.Println(words)
	}

	defer client.Close()

	for i, t := range words {
		c.JSON(200, gin.H{
			"word":       t.Term,
			"definition": t.Definition,
		})
		i++
	}
}

func Save(c *gin.Context) {
	ctx := context.Background()
	projectID := "rising-theater-267614"
	dummy := Word{
		Term:       "Money",
		Definition: "Lets you buy stuff",
	}

	client, err := firestore.NewClient(ctx, projectID)
	if err != nil {
		log.Fatalf("Failed to create client: %v", err)
	}

	defer client.Close()

	_, _, err = client.Collection("FinLit").Add(ctx, map[string]interface{}{
		"Term":       dummy.Term,
		"Definition": dummy.Definition,
	})

	if err != nil {
		log.Fatalf("Failed to add new word: %v", err)
	}
}

func main() {

	r := gin.Default()
	r.GET("/", QueryStrings)
	r.GET("/add", Save)
	r.Run()

}
